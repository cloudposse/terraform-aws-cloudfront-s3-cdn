'use strict';

exports.handler = (event, context, callback) => {
    const request = event.Records[0].cf.request;

    request.headers['X-Custom-Header'] = [{ key: 'X-Custom-Header', value: 'Hello, World!' }];

    callback(null, request);
};